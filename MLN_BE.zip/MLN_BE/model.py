import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import random
from mln import MLNModule
from box_ops import BoxOps

class TransHMLNIntegration(nn.Module):
    def __init__(self, entity_num, relation_num, embedding_dim=100, margin=1.0, learning_rate=0.001, device='cpu'):
        super().__init__()
        self.entity_num = entity_num
        self.relation_num = relation_num
        self.embedding_dim = embedding_dim
        self.margin = margin
        self.device = device

        self.entity_embedding = nn.Embedding(entity_num, embedding_dim)
        self.relation_embedding = nn.Embedding(relation_num, embedding_dim)
        self.relation_hyper = nn.Embedding(relation_num, embedding_dim)

        nn.init.xavier_uniform_(self.entity_embedding.weight.data)
        nn.init.xavier_uniform_(self.relation_embedding.weight.data)
        nn.init.xavier_uniform_(self.relation_hyper.weight.data)

        self.dist_fn = nn.PairwiseDistance(p=2)

        self.mln = MLNModule(embedding_dim, margin)
        self.box_ops = BoxOps()

        self.rule_weights = nn.Parameter(torch.ones(10, device=device))
        self.predicate_embeddings = nn.Embedding(50, embedding_dim)

        self.optimizer = optim.Adam(self.parameters(), lr=learning_rate)
        self.normalize_embeddings()

    def normalize_embeddings(self):
        with torch.no_grad():
            norm = torch.norm(self.relation_hyper.weight, p=2, dim=1, keepdim=True)
            self.relation_hyper.weight.data = self.relation_hyper.weight.data / norm.clamp(min=1e-8)

    def score_triple(self, head, relation, tail):
        h_embed = self.entity_embedding(head)
        r_embed = self.relation_embedding(relation)
        r_hyper = self.relation_hyper(relation)
        t_embed = self.entity_embedding(tail)

        h_proj = h_embed - r_hyper * torch.sum(h_embed * r_hyper, dim=-1, keepdim=True)
        t_proj = t_embed - r_hyper * torch.sum(t_embed * r_hyper, dim=-1, keepdim=True)

        score = self.dist_fn(h_proj + r_embed, t_proj)
        return score

    def update_with_mln_feedback(self, predicates_dict, rules_activated):
        total_loss = 0
        positive_triples = []
        negative_triples = []

        for predicate, confidence in predicates_dict.items():
            if confidence > 0.7:
                triple = self._predicate_to_triple(predicate)
                if triple:
                    positive_triples.append(triple)
            elif confidence < 0.3:
                triple = self._predicate_to_triple(predicate)
                if triple:
                    negative_triples.append(triple)

        if positive_triples:
            pos_tensor = torch.tensor(positive_triples, device=self.device)
            if not negative_triples:
                negative_triples = self._generate_negative_samples(positive_triples)
            neg_tensor = torch.tensor(negative_triples, device=self.device)

            pos_scores = self.score_triple(pos_tensor[:, 0], pos_tensor[:, 1], pos_tensor[:, 2])
            neg_scores = self.score_triple(neg_tensor[:, 0], neg_tensor[:, 1], neg_tensor[:, 2])

            loss = F.relu(pos_scores - neg_scores + self.margin).mean()

            if rules_activated:
                rule_loss = 0
                for rule_id in rules_activated:
                    if rule_id < len(self.rule_weights):
                        rule_loss += torch.abs(self.rule_weights[rule_id] - 1.0)
                loss += 0.1 * rule_loss

            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            self.normalize_embeddings()
            total_loss = loss.item()

        return total_loss

    def _predicate_to_triple(self, predicate):
        predicate_to_relation = {
            'AtLocation': 0, 'Holds': 1, 'IsOpen': 2, 'IsClosed': 3,
            'IsHot': 4, 'IsCool': 5, 'IsClean': 6, 'ActionSucceeded': 7,
            'ActionFailed': 8, 'ContainedIn': 9
        }
        if '(' in predicate:
            pred_name = predicate.split('(')[0]
            if pred_name in predicate_to_relation:
                relation_id = predicate_to_relation[pred_name]
                head_id = random.randint(0, self.entity_num - 1)
                tail_id = random.randint(0, self.entity_num - 1)
                return [head_id, relation_id, tail_id]
        return None

    def _generate_negative_samples(self, positive_triples):
        negative_triples = []
        for h, r, t in positive_triples:
            if random.random() < 0.5:
                h_neg = random.randint(0, self.entity_num - 1)
                negative_triples.append([h_neg, r, t])
            else:
                t_neg = random.randint(0, self.entity_num - 1)
                negative_triples.append([h, r, t_neg])
        return negative_triples

class DiffMarkovMLNIntegration(nn.Module):
    def __init__(self, entity_num, relation_num, embedding_dim=100, hidden_dim=200, margin=1.0, learning_rate=0.001, device='cpu'):
        super().__init__()
        self.entity_num = entity_num
        self.relation_num = relation_num
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.margin = margin
        self.device = device

        self.entity_embedding = nn.Embedding(entity_num, embedding_dim)
        self.relation_normal = nn.Embedding(relation_num, embedding_dim)
        self.relation_trans = nn.Embedding(relation_num, embedding_dim)

        self.intersection_net = nn.Sequential(
            nn.Linear(4 * embedding_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 2 * embedding_dim),
        )

        self.rule_patterns = {}
        self.rule_weights = {}

        nn.init.xavier_uniform_(self.entity_embedding.weight.data)
        nn.init.xavier_uniform_(self.relation_normal.weight.data)
        nn.init.xavier_uniform_(self.relation_trans.weight.data)

        self.optimizer = optim.Adam(self.parameters(), lr=learning_rate)
        self.normalize_relation_embeddings()

    def normalize_relation_embeddings(self):
        with torch.no_grad():
            norm = torch.norm(self.relation_normal.weight, p=2, dim=1, keepdim=True)
            self.relation_normal.weight.data = self.relation_normal.weight.data / norm.clamp(min=1e-8)

    def calculate_score(self, head, relation, tail):
        h_embed = self.entity_embedding(head)
        r_normal = self.relation_normal(relation)
        r_trans = self.relation_trans(relation)
        t_embed = self.entity_embedding(tail)

        h_proj = h_embed - r_normal * torch.sum(h_embed * r_normal, dim=-1, keepdim=True)
        t_proj = t_embed - r_normal * torch.sum(t_embed * r_normal, dim=-1, keepdim=True)

        score = torch.norm(h_proj + r_trans - t_proj, p=2, dim=-1)
        return score

    def mine_rules_from_predicates(self, predicates_dict, threshold=0.7):
        high_conf_predicates = {k: v for k, v in predicates_dict.items() if v > threshold}
        for pred1 in high_conf_predicates:
            for pred2 in high_conf_predicates:
                if pred1 != pred2:
                    pattern = (pred1, pred2)
                    if pattern not in self.rule_patterns:
                        self.rule_patterns[pattern] = 0
                    self.rule_patterns[pattern] += 1
        total_patterns = sum(self.rule_patterns.values())
        if total_patterns > 0:
            for pattern, count in self.rule_patterns.items():
                self.rule_weights[pattern] = count / total_patterns

    def update_with_rules(self, predicates_dict, mln_beliefs):
        self.mine_rules_from_predicates(predicates_dict)
        adjustment_loss = 0
        for predicate, belief in mln_beliefs.items():
            triple = self._predicate_to_triple(predicate)
            if triple:
                h, r, t = triple
                current_score = self.calculate_score(
                    torch.tensor([h], device=self.device),
                    torch.tensor([r], device=self.device), 
                    torch.tensor([t], device=self.device)
                )
                target_score = 1.0 - belief
                adjustment_loss += F.mse_loss(current_score, torch.tensor([target_score], device=self.device))
        if adjustment_loss > 0:
            self.optimizer.zero_grad()
            adjustment_loss.backward()
            self.optimizer.step()
            self.normalize_relation_embeddings()
        return adjustment_loss.item() if adjustment_loss > 0 else 0

    def _predicate_to_triple(self, predicate):
        predicate_to_relation = {
            'AtLocation': 0, 'Holds': 1, 'IsOpen': 2, 'IsClosed': 3,
            'IsHot': 4, 'IsCool': 5, 'IsClean': 6, 'ActionSucceeded': 7,
            'ActionFailed': 8, 'ContainedIn': 9
        }
        if '(' in predicate:
            pred_name = predicate.split('(')[0]
            if pred_name in predicate_to_relation:
                relation_id = predicate_to_relation[pred_name]
                head_id = random.randint(0, self.entity_num - 1)
                tail_id = random.randint(0, self.entity_num - 1)
                return [head_id, relation_id, tail_id]
        return None

class NeuroSymbolicMLNManager:
    def __init__(self, entity_num=100, relation_num=10, embedding_dim=100, model_type='diffmarkov', device='cpu'):
        self.entity_num = entity_num
        self.relation_num = relation_num
        self.embedding_dim = embedding_dim
        self.model_type = model_type
        self.device = device

        if model_type == 'transh':
            self.neural_model = TransHMLNIntegration(entity_num, relation_num, embedding_dim, device=device)
        else:
            self.neural_model = DiffMarkovMLNIntegration(entity_num, relation_num, embedding_dim, device=device)

        self.symbolic_rules = {}
        self.predicate_history = []
        self.update_count = 0

    def update_with_environment_feedback(self, predicates_dict, activated_rules=None):
        self.predicate_history.append(predicates_dict)
        self.update_count += 1

        if self.model_type == 'transh':
            neural_loss = self.neural_model.update_with_mln_feedback(predicates_dict, activated_rules or [])
        else:
            mln_beliefs = self._compute_symbolic_beliefs(predicates_dict)
            neural_loss = self.neural_model.update_with_rules(predicates_dict, mln_beliefs)

        self._update_symbolic_rules(predicates_dict)
        return neural_loss

    def _compute_symbolic_beliefs(self, predicates_dict):
        beliefs = {}
        for predicate, confidence in predicates_dict.items():
            beliefs[predicate] = confidence
            for rule, weight in self.symbolic_rules.items():
                if self._rule_applicable(rule, predicate):
                    derived_belief = confidence * weight
                    derived_predicate = self._apply_rule(rule, predicate)
                    if derived_predicate:
                        beliefs[derived_predicate] = max(beliefs.get(derived_predicate, 0), derived_belief)
        return beliefs

    def _update_symbolic_rules(self, predicates_dict):
        high_conf_preds = [p for p, c in predicates_dict.items() if c > 0.7]
        if len(high_conf_preds) >= 2:
            for i in range(len(high_conf_preds)):
                for j in range(i + 1, len(high_conf_preds)):
                    rule = f"{high_conf_preds[i]} → {high_conf_preds[j]}"
                    if rule not in self.symbolic_rules:
                        self.symbolic_rules[rule] = 0.1
                    else:
                        self.symbolic_rules[rule] = min(1.0, self.symbolic_rules[rule] + 0.1)

    def _rule_applicable(self, rule, predicate):
        return predicate in rule.split(' → ')[0]

    def _apply_rule(self, rule, predicate):
        parts = rule.split(' → ')
        if len(parts) == 2 and predicate == parts[0]:
            return parts[1]
        return None

    def get_prediction_scores(self, action_predicates_list):
        scores = []
        for predicates in action_predicates_list:
            score = 0
            count = 0
            for predicate, confidence in predicates.items():
                triple = self.neural_model._predicate_to_triple(predicate)
                if triple:
                    h, r, t = triple
                    neural_score = self.neural_model.calculate_score(
                        torch.tensor([h], device=self.device),
                        torch.tensor([r], device=self.device),
                        torch.tensor([t], device=self.device)
                    ).item()
                    combined_score = neural_score * (1 - confidence)
                    score += combined_score
                    count += 1
            avg_score = score / max(1, count)
            scores.append(avg_score)
        return scores

class MLNBoxEmbedding(nn.Module):
    def __init__(self, nentity, nrelation, embedding_dim=100, margin=1.0, learning_rate=0.001, device='cpu'):
        super().__init__()
        self.neuro_symbolic = NeuroSymbolicMLNManager(nentity, nrelation, embedding_dim, 'transh', device)
        self.mln = MLNModule(embedding_dim, margin)
        self.box_ops = BoxOps()

    def forward(self, sample, rel_len, qtype, mode):
        # 使用你提供的neuro_symbolic进行前向
        return self.neuro_symbolic.neural_model.score_triple(sample[:,0], sample[:,1], sample[:,2])

    @staticmethod
    def train_step(model, optimizer, train_iterator, args, step):
        return model.neuro_symbolic.neural_model.train_step(model.neuro_symbolic.neural_model, optimizer, train_iterator, args, step)

    @staticmethod
    def test_step(model, test_triples, test_ans, test_ans_hard, args):
        return model.neuro_symbolic.neural_model.test_step(model.neuro_symbolic.neural_model, test_triples, test_ans, test_ans_hard, args)