#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <vector>
#include <cmath>

namespace py = pybind11;

py::array_t<double> vem_optimize(py::array_t<double> formulas, int max_iter) {
    auto buf = formulas.request();
    double* data = static_cast<double*>(buf.ptr);
    size_t n = buf.shape[0];
    
    std::vector<double> weights(n, 1.0 / n);
    
    for (int iter = 0; iter < max_iter; ++iter) {
        double sum = 0.0;
        for (size_t i = 0; i < n; ++i) {
            double e = std::exp(data[i]);
            weights[i] = e;
            sum += e;
        }
        for (size_t i = 0; i < n; ++i) {
            weights[i] /= sum;
        }
    }
    
    py::array_t<double> result(n);
    auto res_buf = result.request();
    double* res_ptr = static_cast<double*>(res_buf.ptr);
    for (size_t i = 0; i < n; ++i) res_ptr[i] = weights[i];
    
    return result;
}

PYBIND11_MODULE(vem, m) {
    m.def("vem_optimize", &vem_optimize);
}