MLN-Box: Exact merge of nesy_mln_integration.py + tex paper formulas

MLN formulas construction (intersection/union/negation/chain) from tex.
MLN learning and reasoning from your nesy_mln_integration.py.
12 query types: 1p 2p 3p 2i 3i ip pi 2u up 2d 3d dp
Metrics: MRR Hit@1 Hit@3 Hit@10
Training process fully visible.

Run:
python setup.py build_ext --inplace
python run.py --data_path data/FB15k-237 --do_train --do_valid --do_test --model MLNBox --geo box --task 1p.2p.3p.2i.3i.ip.pi.2u.up.2d.3d.dp --hidden_dim 400 --batch_size 512 --max_steps 300000