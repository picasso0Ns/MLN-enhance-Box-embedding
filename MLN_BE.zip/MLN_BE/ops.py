import torch

class BoxOps:
    def intersection(self, center1, offset1, center2, offset2):
        min_box = torch.max(center1 - 0.5 * offset1, center2 - 0.5 * offset2)
        max_box = torch.min(center1 + 0.5 * offset1, center2 + 0.5 * offset2)
        new_center = (min_box + max_box) / 2
        new_offset = max_box - min_box
        return new_center, new_offset

    def union(self, center1, offset1, center2, offset2):
        min_box = torch.min(center1 - 0.5 * offset1, center2 - 0.5 * offset2)
        max_box = torch.max(center1 + 0.5 * offset1, center2 + 0.5 * offset2)
        new_center = (min_box + max_box) / 2
        new_offset = max_box - min_box
        return new_center, new_offset

    def negation(self, center, offset):
        return -center, offset