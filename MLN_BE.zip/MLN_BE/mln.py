import torch
from vem import vem_optimize

class MLNModule(torch.nn.Module):
    def __init__(self, dim, gamma):
        super().__init__()
        self.dim = dim
        self.gamma = gamma

    def build_intersection_formula(self, centers, relations):
        formulas = torch.zeros(centers.shape[0], dtype=torch.float32, device=centers.device)
        for i in range(centers.shape[0]):
            formulas[i] = centers[i, 0] * relations[i, 0] + centers[i, 1] * relations[i, 1]
        return formulas

    def build_union_formula(self, centers, relations):
        formulas = torch.zeros(centers.shape[0], dtype=torch.float32, device=centers.device)
        for i in range(centers.shape[0]):
            formulas[i] = centers[i, 0] * relations[i, 0] + centers[i, 1] * relations[i, 1] + centers[i, 2] * relations[i, 2]
        return formulas

    def build_negation_formula(self, centers, relations):
        formulas = torch.zeros(centers.shape[0], dtype=torch.float32, device=centers.device)
        for i in range(centers.shape[0]):
            formulas[i] = -centers[i, 0] * relations[i, 0]
        return formulas

    def build_chain_formula(self, centers, relations):
        formulas = torch.zeros(centers.shape[0], dtype=torch.float32, device=centers.device)
        for i in range(centers.shape[0]):
            formulas[i] = centers[i, 0] * relations[i, 0]
            for r in range(1, relations.shape[1]):
                formulas[i] = formulas[i] + centers[i, 0] * relations[i, r]
        return formulas

    def compute_weights(self, centers, relations, qtype):
        if "inter" in qtype:
            formulas = self.build_intersection_formula(centers, relations)
        elif "union" in qtype:
            formulas = self.build_union_formula(centers, relations)
        elif "d" in qtype:
            formulas = self.build_negation_formula(centers, relations)
        else:
            formulas = self.build_chain_formula(centers, relations)
        weights_np = vem_optimize(formulas.cpu().numpy(), 30)
        return torch.tensor(weights_np, dtype=torch.float32, device=centers.device)