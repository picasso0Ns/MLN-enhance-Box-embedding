from setuptools import setup
from pybind11.setup_helpers import Pybind11Extension, build_ext

ext_modules = [
    Pybind11Extension(
        "vem",
        ["vem.cpp"],
        extra_compile_args=["-O3", "-std=c++17"]
    ),
]

setup(
    name="mln_box",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
)